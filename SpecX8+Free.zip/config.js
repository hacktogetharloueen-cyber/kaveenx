module.exports = {
  BOT_TOKEN: "isi token bot",
  OWNER_ID: 7707404792
}